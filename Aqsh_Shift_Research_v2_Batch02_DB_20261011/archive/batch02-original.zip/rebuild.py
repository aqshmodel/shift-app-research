#!/usr/bin/env python3
from pathlib import Path
import sqlite3,sys
root=Path(__file__).resolve().parent
out=Path(sys.argv[1]) if len(sys.argv)>1 else root/'rebuilt.sqlite3'
if out.exists():
    raise SystemExit('Destination exists; choose another path. Existing files are not overwritten.')
c=sqlite3.connect(out)
c.executescript((root/'restore_all.sql').read_text(encoding='utf-8'))
c.execute('PRAGMA foreign_keys=ON')
assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
assert not c.execute('PRAGMA foreign_key_check').fetchall()
assert c.execute('SELECT count(*) FROM v_current40').fetchone()[0]==2000
assert c.execute('SELECT count(*) FROM products').fetchone()[0]==50
c.close()
print(out)
