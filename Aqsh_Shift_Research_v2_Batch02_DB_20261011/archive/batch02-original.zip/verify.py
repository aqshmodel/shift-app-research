#!/usr/bin/env python3
from pathlib import Path
import sqlite3,json,sys
root=Path(__file__).resolve().parent
p=Path(sys.argv[1]) if len(sys.argv)>1 else root/'Aqsh_Shift_Research_v2_Batch02_20261011.sqlite3'
c=sqlite3.connect(p)
checks={
 'integrity':c.execute('PRAGMA integrity_check').fetchone()[0]=='ok',
 'foreign_keys':not c.execute('PRAGMA foreign_key_check').fetchall(),
 'products_50':c.execute('SELECT count(*) FROM products').fetchone()[0]==50,
 'common40_slots_2000':c.execute('SELECT count(*) FROM v_current40').fetchone()[0]==2000,
 'criteria_164':c.execute('SELECT count(*) FROM criteria').fetchone()[0]==164,
 'no_performance_runs_claimed':c.execute('SELECT count(*) FROM benchmark_runs').fetchone()[0]==0,
 'unknown_costs_stay_null':c.execute("SELECT count(*) FROM price_components WHERE amount_status!='known' AND unit_amount_decimal IS NOT NULL").fetchone()[0]==0}
print(json.dumps({'scope':'DB integrity, not competitor performance','passed':all(checks.values()),'checks':checks},ensure_ascii=False,indent=2))
raise SystemExit(0 if all(checks.values()) else 1)
