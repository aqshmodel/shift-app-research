-- 最新の共通項目だけ。旧い観測を直接全結合しない。
SELECT * FROM v_current40 WHERE product_id IN ('JP01','JP20','JP24') ORDER BY criterion_id,product_id;
-- 一製品を出典付きで深掘り（歴史的観測も表示）
SELECT * FROM v_observations_with_sources WHERE product_id='JP28' ORDER BY criterion_id,observation_id;
-- 確定していない共通項目
SELECT * FROM v_unresolved40 WHERE product_id='US11';
-- 料金の原額・条件。代替プランを合計しない。
SELECT * FROM v_price_details WHERE product_id IN ('JP24','US11','US19','US21');
-- 今回の差分のみ
SELECT * FROM observations WHERE json_extract(applicability_json,'$.research_batch')='B02-20261011';
-- 情報の出所の性格
SELECT s.title,s.canonical_url,a.* FROM source_method_attributes a JOIN source_revisions r USING(revision_id) JOIN sources s USING(source_id);
